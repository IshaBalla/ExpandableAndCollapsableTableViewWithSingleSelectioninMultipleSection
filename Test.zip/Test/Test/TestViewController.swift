//
//  TestViewController.swift
//  Test
//
//  Created by ObjcData on 6/14/16.
//  Copyright © 2016 Golchha. All rights reserved.
//

import UIKit

class TestViewController: UIViewController,UITableViewDataSource,UITableViewDelegate{
    
    @IBOutlet weak var tableView: UITableView!
    
    var arrayForBool : [Int] = []
    
    var arrSelectedRow = [AnyObject]()
    
    var arrSelectedSection = [AnyObject]()
    
    var selectedItemIndex : Int?
    
    
    var FilterConstant = 0
    
    //MARK:- Data Array
    
    var data = [
    "attributesTypes":
        [
    
    [
        
    "id": 1,
    "type": "type1",
    "multiSelect": true,
    "itemsAttribute":
        
        
    [
        [
    "id": 1,
    "attribute": "large",
    "unitPrice": 100
    ],
    
    [
    "id": 2,
    "attribute": "small",
    "unitPrice": 50
    ]
    ]
        ],
    
    [
    "id": 2,
    "type": "type2",
    "multiSelect": true,
    "itemsAttribute":
    [
     
    [
    "id": 3,
    "attribute": "red",
    "unitPrice": 456
    ],
      
    [
    "id": 4,
    "attribute": "green",
    "unitPrice": 456
    ],
        [
            "id": 5,
            "attribute": "brown",
            "unitPrice": 456
        ]
        ]
    ]
            ]
]

    
    override func viewDidLoad() {
        super.viewDidLoad()

    
        
        for item in self.data["attributesTypes"]! {
            self.arrayForBool.append(Int(false))
            self.arrSelectedRow.removeAll()
            let k = item.valueForKey("itemsAttribute") as! [NSDictionary]
            for ite in k {
                self.arrSelectedRow.append(FilterConstant)
            }
            self.arrSelectedSection.append(arrSelectedRow)
        }
       
       
       
       
        
        // Do any additional setup after loading the view.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        let k = self.data["attributesTypes"]
        
        return (k?.count)!
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if CBool(self.arrayForBool[section] ) {
            let k = self.data["attributesTypes"]![section]["itemsAttribute"]
            
            return (k?.count)!
        } else {
            return 0
        }
      
       
      
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
               
        
        
        let manyCells: Bool = CBool(arrayForBool[indexPath.section] as! NSNumber)
        if !manyCells {
            cell.backgroundColor = UIColor.clearColor()
            cell.textLabel!.text = ""
            
        }
        else {
            
            let oneData = self.data["attributesTypes"]![indexPath.section ]["itemsAttribute"]![indexPath.row ]!
            
            let k = oneData.valueForKey("attribute")
            
            let selectedData:Int = oneData.valueForKey("id") as! Int
            let checkbox = self.arrSelectedSection[indexPath.section][indexPath.row]
            
            cell.textLabel!.text = k as? String
            
            if selectedData != checkbox as! Int   {
                cell.accessoryType = .None
            } else {
                cell.accessoryType = .Checkmark
            }

            
            
        return cell
        }
        return UITableViewCell()
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
       
        
        let cell = tableView.cellForRowAtIndexPath(indexPath)
        
        let oneData = self.data["attributesTypes"]![indexPath.section ]["itemsAttribute"]![indexPath.row ]!
        
      
        
        let selectedData:Int = oneData.valueForKey("id") as! Int
        
     
        
        let checkbox = self.arrSelectedSection[indexPath.section][indexPath.row]
        
        self.arrSelectedRow = arrSelectedSection[indexPath.section] as! [AnyObject]
        self.arrSelectedRow.removeAll()
        
        let ki = self.data["attributesTypes"]![indexPath.section ]["itemsAttribute"]! as! [NSDictionary]
        for i in 0..<ki.count {
           
            if i != indexPath.row {
                self.arrSelectedRow.append(FilterConstant)
            }

        }
        if selectedData != checkbox as! Int{
            self.arrSelectedRow.insert(selectedData, atIndex:indexPath.row)
        }else{
            self.arrSelectedRow.insert(self.FilterConstant, atIndex:indexPath.row)
        }
        
        self.arrSelectedSection.removeAtIndex(indexPath.section)
        self.arrSelectedSection.insert(self.arrSelectedRow, atIndex:indexPath.section)
        self.tableView.reloadData()
       
}
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if CBool(arrayForBool[indexPath.section] as! NSNumber) {
            return 40
        }
        return 0
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
    let sectionView: UIView = UIView(frame: CGRectMake(0, 0, 280, 40))
    sectionView.tag = section
    let viewLabel: UILabel = UILabel(frame: CGRectMake(10, 0, self.tableView.frame.size.width - 10, 40))
    viewLabel.backgroundColor = UIColor.clearColor()
    viewLabel.textColor = UIColor.blackColor()
    viewLabel.font = UIFont.systemFontOfSize(15)
    viewLabel.text = "Attribute" +  " " + String(section + 1)
    sectionView.addSubview(viewLabel)
    /********** Add a custom Separator with Section view *******************/
    let separatorLineView: UIView = UIView(frame: CGRectMake(15, 40, self.tableView.frame.size.width - 15, 1))
    separatorLineView.backgroundColor = UIColor.blackColor()
    sectionView.addSubview(separatorLineView)
    /********** Add UITapGestureRecognizer to SectionView   **************/
    let headerTapped: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(TestViewController.sectionHeaderTapped(_:)))
    sectionView.addGestureRecognizer(headerTapped)
    return sectionView
    }
    
    func sectionHeaderTapped(gestureRecognizer: UITapGestureRecognizer) {
        let indexPath: NSIndexPath = NSIndexPath(forRow: 0, inSection: gestureRecognizer.view!.tag)
        if indexPath.row == 0 {
            let collapsed: Bool = CBool(arrayForBool[indexPath.section] as NSNumber)
            for i in 0 ..< self.data["attributesTypes"]!.count {
                if indexPath.section == i {
                    arrayForBool[i] = Int(!collapsed)
                }
            }
            self.tableView.reloadSections(NSIndexSet(index: gestureRecognizer.view!.tag), withRowAnimation: .Automatic)
        }
    }


    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }

   

   

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
}
