//
//  CheckMarkTestViewController.swift
//  Test
//
//  Created by ObjcData on 6/15/16.
//  Copyright © 2016 Golchha. All rights reserved.
//

import UIKit

class CheckMarkTestViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tblView: UITableView!
    
    var array = [["First","Second","Third","Fourth","Fifth","Sixth"],["The","name","Is"]]
    var arrSelectedRow = [AnyObject]()
    var arrSelectedSection = [AnyObject]()
    var filterConstant = "kk"
    
    
    var selectedItemIndex : Int?
    var selectedItemSection: Int?
    var selectedIndex :[NSMutableArray] = []
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        for i in 0..<self.array.count {
            self.arrSelectedRow.removeAll()
            
        let k = self.array[i]
            
            for item in k {
               
                self.arrSelectedRow.append(filterConstant)
                print("Here the arrseelctedrow is \(self.arrSelectedRow)")

            }
             self.arrSelectedSection.append(arrSelectedRow)

        }
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return self.array.count
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.array[section].count
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
        cell.textLabel?.text = self.array[indexPath.section][indexPath.row]
        
        let selectedData = self.array[indexPath.section][indexPath.row]
        let checkbox = self.arrSelectedSection[indexPath.section][indexPath.row]
        if selectedData != checkbox as! String {
            cell.accessoryType = .None
        } else {
            cell.accessoryType = .Checkmark
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "This is the section \(section)"
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath){
        var indexPaths = tableView.indexPathForSelectedRow
        
        let cell = self.tblView.cellForRowAtIndexPath(indexPath)
        
        
//        if indexPaths!.row != self.selectedItemIndex {
//            
//            
//            if let selectedItemIndex = self.selectedItemIndex {
//                
//                let previousCell = self.tblView.cellForRowAtIndexPath(NSIndexPath(forItem: selectedItemIndex, inSection: indexPaths!.section))
//                previousCell?.accessoryType = UITableViewCellAccessoryType.None
//            }
//            
//            self.selectedItemIndex = indexPath.row
//            
//        }
//        
//        if cell?.accessoryType == UITableViewCellAccessoryType.Checkmark {
//            cell?.accessoryType = .None
//        } else {
//            cell?.accessoryType = .Checkmark
//        }
//        
//        
//    }
        
        let selectedData = self.array[indexPath.section][indexPath.row]
        let checkbox = self.arrSelectedSection[indexPath.section][indexPath.row]
        
        self.arrSelectedRow = arrSelectedSection[indexPath.section] as! [AnyObject]
        self.arrSelectedRow.removeAll()
        let k = self.array[indexPath.section]
        
        for i in 0..<k.count {
            if i != indexPath.row {
                self.arrSelectedRow.append(filterConstant)
            }
        }
        if selectedData != checkbox as! String{
            self.arrSelectedRow.insert(selectedData, atIndex:indexPath.row)
        }else{
            self.arrSelectedRow.insert(self.filterConstant, atIndex:indexPath.row)
        }
        
        self.arrSelectedSection.removeAtIndex(indexPath.section)
        self.arrSelectedSection.insert(self.arrSelectedRow, atIndex:indexPath.section)
        self.tblView.reloadData()

        
        
}
}



